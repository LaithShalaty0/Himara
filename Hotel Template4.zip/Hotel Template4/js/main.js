/* global $, alert*/

$(function () {
    'use strict';

    // var mySlider = $('.carousel-inner'),
    //     parallax = $('.carousel-item .parallax')

    // // Adjust slider Height

    // mySlider.height($(window).height() - 80);

    // $(window).resize(function () {
    //     mySlider.height($(window).height() - 80);

    //     $('.carousel-item img').each(function () {
    //         $(this).css('paddingTop', ($(window).height() - $('.slider div.carousel-inner div.carousel-item img').height()) / 2);
    //     });
    // });

    // parallax.height($(window).height() - 80);

    // $(window).resize(function () {
    //     parallax.height($(window).height() - 80);

    //     $('.parallax').each(function () {
    //         $(this).css('paddingTop', ($(window).height() - $('.parallax').height()) / 2);
    //     });
    // });

    // Fixed Header

    $(function () {
        $(window).scroll(function () {
            var winTop = $(window).scrollTop();
            if (winTop >= 30) {
                $("header").addClass("fixed-top");
                $(".restaurant-poster").css({
                    "marginTop": "30px"
                });
            } else {
                $("header").removeClass("fixed-top");
                $(".restaurant-poster").css({
                    "marginTop": "0"
                });
            }//if-else
        });//win func.


        $('.pop').on('click', function () {
            $('.imagepreview').attr('src', $(this).find('img').attr('src'));
            $('#imagemodal').modal('show');
        });
    });//ready func.

    // Owl Carousel

    $('.gallery-owl').owlCarousel({
        items: 5,
        loop: true,
        margin: 30,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 5
            }
        }
    })

    $('.testimonials-owl').owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        nav: false,
        dot: true,
        dotsEach: 4,
        responsive: {
            0: {
                items: 1,
                nav: false,
                dots: false
            },
            600: {
                items: 2,
                nav: false,
                dots: false
            },
            1000: {
                items: 3
            }
        }
    })

    // Links Add Active Class

    $('.links li').click(function () {
        $(this).addClass('active').siblings().removeClass('active');
    });

    // Adjust Shuffle Links

    $('.shuffle li').click(function () {
        $(this).addClass('selected').siblings().removeClass('selected');
    });

    // Tooltip

    $('[data-toggle="tooltip"]').tooltip()

    // PopOver

    $('[data-toggle="popover"]').popover()

    // Magnific Popup

    $('.popup-vimeo').magnificPopup({
        type: 'iframe'
    });

});

function initialize() {
    var mapOptions = {
        center: new google.maps.LatLng(28.1823295, -82.352912),
        zoom: 9,
        mapTypeId: google.maps.MapTypeId.HYBRID,
        scrollwheel: true,
        draggable: true,
        panControl: false,
        zoomControl: false,
        mapTypeControl: false,
        scaleControl: false,
        streetViewControl: false,
        overviewMapControl: true,
        rotateControl: true,
    };
    var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
}
google.maps.event.addDomListener(window, 'load', initialize);